//
//  VimaiFramework.h
//  VimaiFramework
//
//  Created by Klaudas Jankauskas on 2020-03-29.
//  Copyright © 2020 vimai. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for VimaiFramework.
FOUNDATION_EXPORT double VimaiFrameworkVersionNumber;

//! Project version string for VimaiFramework.
FOUNDATION_EXPORT const unsigned char VimaiFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VimaiFramework/PublicHeader.h>

